﻿<div class="erreur">
<ul>
<?php
foreach($msgErreurs as $erreur)
	{
 ?>     
	  <li><?php echo $erreur ?></li>
<?php	  
	}
?>
</ul>
</div>
