<div id="accueil">
Lafleur, le prince des fleurs sur internet
</div>
