﻿<div class="message">
<ul><li>
<?php
      echo $message;
?>
</li>
</ul>
</div>